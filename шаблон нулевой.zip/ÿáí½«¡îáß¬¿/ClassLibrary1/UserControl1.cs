﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ClassLibrary1
{
    public partial class UserControl1 : UserControl
    {

        public class Number : EventArgs
        {
            public byte Num { get; set; }
        }
        public delegate void DelEvNum(object sender, Number e);
        public event DelEvNum NumEv;

 

        public UserControl1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            byte n = byte.Parse(b.Text);
            if (NumEv != null)
            {
                NumEv(this, new Number { Num = n });
            }
        }
    }
}
